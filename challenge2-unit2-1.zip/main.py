'''Implement a class called player that represents a cricket player. The player class should have a
method called play() Which prints "The player is playing cricket. Derive two classes, Batsman and
Bowler, from the player class. Override the play() method in each derived class to print "The batsman
is batting" and "The bowler is blowing", respectively. Write a program to create objects of both the
Batsman and bowler classes and call the play() method for each object.'''


# Define the base class_player
class Player:
    def play(self):
        print("The player is playing cricket.")

# Define the derived class Batsman
class Batsman(Player):
    def play(self):
        print("The batsman is bowling.")

# Define the derived class Bowler
class Bowler(Player):
    def play(self):
        print("The bowler is blowing.")

# Create objects of Batsman and Bowler class
batsman = Batsman()
bowler = Bowler()

# Call the play() method for each object
batsman.play()
bowler.play()
